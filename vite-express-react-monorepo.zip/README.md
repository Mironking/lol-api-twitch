# Express + Vite + React + TypeScript Monorepo

## 🛠 Стек
- Express.js (сервер)
- React + Vite (клієнт)
- TypeScript

## 🚀 Запуск

```bash
npm install
npm run dev
```
